export const noop = () => {};
